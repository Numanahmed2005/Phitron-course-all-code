#include <stdio.h>

int main() {
  int a ;
  
  int i = 1 ;
  while ( i<= 5)
{

  printf("%d", i);
  i++ ;
}
 




  return 0;
}